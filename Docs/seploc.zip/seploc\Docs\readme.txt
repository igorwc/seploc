Igor (13/10/2011)
Trabalhando na gera��o de Relat�rio de requisi��es de clientes por periodo.
Os campos do form de gera��o ser�o obrigat�rios, com exce��o do desconto.
S� gerar� o relat�rio caso as datas e o cliente sejam informados.
Modelo atualizado para que o valor do desconto seja armazenado no banco. Estou vendo que caso o desconto seja de 15% por exemplo,
o desconto deve ser replicado em todas as consultas no banco, que satisfizerem a condi��o informada pelo usu�rio.

Gustavo
Requisi��o de Servi�o (07-Set)