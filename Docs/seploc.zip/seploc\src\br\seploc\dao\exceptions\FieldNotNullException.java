package br.seploc.dao.exceptions;

public class FieldNotNullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FieldNotNullException() {
		// TODO Auto-generated constructor stub
	}

	public FieldNotNullException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public FieldNotNullException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public FieldNotNullException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
