package br.seploc.dao.exceptions;

public class ParentDeleteException extends Exception {

	private static final long serialVersionUID = -6321667402700705340L;

	public ParentDeleteException() {
		
	}

	public ParentDeleteException(String arg0) {
		super(arg0);
		
	}

	public ParentDeleteException(Throwable arg0) {
		super(arg0);
		
	}

	public ParentDeleteException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

}
