package br.seploc.dao.exceptions;

public class PrimaryKeyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6671362645543617633L;

	public PrimaryKeyException() {
		// TODO Auto-generated constructor stub
	}

	public PrimaryKeyException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PrimaryKeyException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PrimaryKeyException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
