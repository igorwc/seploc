package br.seploc.dao.exceptions;

public class RecordNotFound extends Exception {

	public RecordNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RecordNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RecordNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RecordNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
