package br.seploc.mbeans;

public class ReqServBalcaoMB {

}
